#!/usr/bin/env bash
# bc250-cu-leave-one-out.sh
#
# Find defective WGPs on a 40-CU-unlocked BC-250 by leave-one-out testing.
# No reboots. No persistent modprobe state. Must be run from a TTY (no
# graphical session active) since amdgpu is unloaded/reloaded between
# iterations.
#
# For each of the 20 WGPs (5 per shader array * 2 SE * 2 SH):
#   - unload amdgpu
#   - modprobe amdgpu with disable_cu masking the 2 CUs of that WGP (38 CU active)
#   - run compute verifier with a hard timeout
#   - record errors
# Always restores full 40 CU at the end, even on Ctrl-C / failure.

set -euo pipefail

ELEMENTS="${BC250_LOO_ELEMENTS:-4194304}"
PASSES="${BC250_LOO_PASSES:-2}"
ITERS="${BC250_LOO_ITERS:-32}"
VERIFY_TIMEOUT="${BC250_LOO_TIMEOUT:-60}"
OUTDIR="${BC250_LOO_OUTDIR:-/var/lib/bc250-cu-leave-one-out}"
RESULTS="$OUTDIR/results.tsv"
RESTORE_OPTS="${BC250_LOO_RESTORE_OPTS:-bc250_cc_write_mode=3}"

die() { echo "ERROR: $*" >&2; exit 1; }
log() { printf '\033[0;32m[loo]\033[0m %s\n' "$*"; }
warn() { printf '\033[0;33m[loo]\033[0m %s\n' "$*" >&2; }

[ "$(id -u)" = "0" ] || die "must run as root"

# Refuse to run if a display server is active — rmmod amdgpu would hang/kill it
if pgrep -x Xorg >/dev/null 2>&1 || pgrep -x Xwayland >/dev/null 2>&1 \
   || pgrep -x kwin_wayland >/dev/null 2>&1 || pgrep -x gnome-shell >/dev/null 2>&1 \
   || pgrep -x sway >/dev/null 2>&1 || pgrep -x Hyprland >/dev/null 2>&1; then
    die "graphical session is active. Switch to TTY (Ctrl+Alt+F3), stop your display manager (e.g. 'systemctl stop plasmalogin'), then re-run."
fi

command -v glslangValidator >/dev/null || die "glslangValidator missing (pacman -S glslang)"
command -v gcc >/dev/null || die "gcc missing"
command -v timeout >/dev/null || die "timeout missing (coreutils)"

VERIFY_SRC="$(dirname "$(readlink -f "$0")")/bc250-compute-verify.sh"
[ -f "$VERIFY_SRC" ] || die "bc250-compute-verify.sh not found next to this script"

mkdir -p "$OUTDIR"

# Build the verify binary once by running compute-verify with --keep-tmp
# and a tiny problem size so we just exercise the build path.
log "building verify binary (one-time)..."
BUILD_LOG="$(mktemp)"
trap 'rm -f "$BUILD_LOG"' EXIT
if ! "$VERIFY_SRC" --elements 256 --passes 1 --iters 1 --keep-tmp >"$BUILD_LOG" 2>&1; then
    cat "$BUILD_LOG" >&2
    die "verify build failed"
fi
TMPDIR_VERIFY="$(grep -oP 'Keeping temporary files in \K.*' "$BUILD_LOG")"
[ -n "$TMPDIR_VERIFY" ] && [ -x "$TMPDIR_VERIFY/bc250_compute_verify" ] \
    || die "could not locate built verify binary"
VERIFY_BIN="$TMPDIR_VERIFY/bc250_compute_verify"
VERIFY_SPV="$TMPDIR_VERIFY/bc250_compute_verify.spv"
log "verify binary: $VERIFY_BIN"

reload_amdgpu() {
    local opts="$1"
    # Best-effort unload; busy modules will fail until consumers release them.
    local tries=0
    while lsmod | grep -q '^amdgpu '; do
        rmmod amdgpu 2>/dev/null || true
        tries=$((tries+1))
        [ "$tries" -gt 10 ] && die "could not rmmod amdgpu (busy)"
        sleep 0.5
    done
    # shellcheck disable=SC2086
    modprobe amdgpu $opts
    # Wait for render node
    local waited=0
    while [ ! -e /dev/dri/renderD128 ]; do
        sleep 0.5
        waited=$((waited+1))
        [ "$waited" -gt 20 ] && die "renderD128 did not appear after modprobe amdgpu $opts"
    done
    # Small settle delay for SMU/firmware
    sleep 1
}

restore_full() {
    log "restoring 40 CU (no disable_cu)..."
    reload_amdgpu "$RESTORE_OPTS" || warn "restore reload failed; system may need manual modprobe"
}
trap 'rm -f "$BUILD_LOG"; restore_full' EXIT

# WGP layout: 2 SE * 2 SH * 5 WGPs * 2 CU/WGP = 40 CU
# CU index within (SE,SH): WGP n occupies CUs 2n, 2n+1.

echo -e "iter\tSE\tSH\tWGP\tcu_a\tcu_b\terrors\tint_errors\tfp_errors\ttime_sec\tstatus" >"$RESULTS"
log "results: $RESULTS"
log "settings: elements=$ELEMENTS passes=$PASSES iters=$ITERS timeout=${VERIFY_TIMEOUT}s"

iter=0
total=20
for se in 0 1; do
    for sh in 0 1; do
        for wgp in 0 1 2 3 4; do
            iter=$((iter+1))
            cu_a=$((wgp*2)); cu_b=$((wgp*2+1))
            mask="${se}.${sh}.${cu_a},${se}.${sh}.${cu_b}"
            log "[$iter/$total] disable WGP SE${se}/SH${sh}/WGP${wgp}  (CUs ${cu_a},${cu_b}) — 38 CU active"

            reload_amdgpu "bc250_cc_write_mode=3 disable_cu=${mask}"

            t0=$(date +%s.%N)
            status="ok"
            errs=0; ie=0; fe=0
            if ! out=$(timeout --kill-after=5 "${VERIFY_TIMEOUT}" \
                       "$VERIFY_BIN" "$VERIFY_SPV" "$ELEMENTS" "$PASSES" "$ITERS" 2>&1); then
                rc=$?
                if [ "$rc" = "124" ] || [ "$rc" = "137" ]; then
                    status="TIMEOUT"
                else
                    status="FAIL($rc)"
                fi
                warn "iter $iter: $status"
            fi
            t1=$(date +%s.%N)
            dt=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.2f", b-a}')

            if [ "$status" = "ok" ]; then
                # Parse summary line:
                # summary elements=... passes=... total_checked=... errors=N int_errors=N fp_errors=N
                line=$(echo "$out" | grep '^summary ' | tail -1 || true)
                if [ -n "$line" ]; then
                    errs=$(echo "$line"  | grep -oP 'errors=\K[0-9]+' | head -1)
                    ie=$(echo   "$line"  | grep -oP 'int_errors=\K[0-9]+')
                    fe=$(echo   "$line"  | grep -oP 'fp_errors=\K[0-9]+')
                else
                    status="NO_SUMMARY"
                    warn "iter $iter: no summary line in verify output"
                fi
            fi

            echo -e "${iter}\t${se}\t${sh}\t${wgp}\t${cu_a}\t${cu_b}\t${errs}\t${ie}\t${fe}\t${dt}\t${status}" >>"$RESULTS"
            log "[$iter/$total]   ${dt}s  errors=${errs} int=${ie} fp=${fe} status=${status}"
        done
    done
done

log ""
log "=== Summary (sorted by errors) ==="
{
    head -1 "$RESULTS"
    tail -n +2 "$RESULTS" | sort -t$'\t' -k7,7nr -k8,8nr
} | column -t -s $'\t'

# Suggest candidates: any WGP whose removal yields 0 errors AND others have errors
log ""
zero_err_wgps=$(tail -n +2 "$RESULTS" | awk -F'\t' '$7==0 && $11=="ok" {print $2"."$3"."$5","$2"."$3"."$6}')
if [ -n "$zero_err_wgps" ]; then
    log "WGPs whose removal yields 0 errors (likely defective — pick the one shared by all clean runs):"
    echo "$zero_err_wgps" | sed 's/^/    disable_cu=/'
else
    log "No WGP removal alone cleared all errors. May be multiple defects or non-CU issue."
fi

log ""
log "Done. Full 40 CU mode will be restored on exit."
log "If you want to persist a mask:  ./bc250-cu-mask.sh --bad-cu <SE.SH.CU,...> --install"
