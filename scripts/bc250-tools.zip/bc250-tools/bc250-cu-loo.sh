#!/usr/bin/env bash
# bc250-cu-loo.sh — reboot-based leave-one-out WGP defect finder for BC-250.
#
# Safer than the upstream bc250-cu-health-test.sh: every iteration leaves
# 38 of 40 CUs active (1 WGP disabled), so GPU init can't fail catastrophically
# from masking out too much. Persistent state, auto-resume across reboots,
# clean rollback via `cancel`.
#
# Commands:
#   start             begin the test (writes first conf, installs service, reboots)
#   resume            internal — called by systemd at boot
#   step              run one iteration without rebooting (for debug/manual mode)
#   status            print state and partial results
#   cancel            stop test, remove modprobe conf and systemd service
#   show-results      print results.tsv as a table
#
# Recovery if a bad boot:
#   1. GRUB → Snapshots → boot a pre-test snapper snapshot, OR
#   2. GRUB → edit kernel cmdline, add 'module_blacklist=amdgpu' to boot
#      without GPU; then `sudo rm /etc/modprobe.d/bc250-cu-loo.conf`
#      and `sudo /home/kioval/bc250-tools/bc250-cu-loo.sh cancel`.

set -euo pipefail

STATE_DIR="${BC250_LOO_STATE:-/var/lib/bc250-cu-loo}"
STATE_FILE="$STATE_DIR/state"
RESULTS="$STATE_DIR/results.tsv"
LOG="$STATE_DIR/run.log"
MODPROBE_CONF="/etc/modprobe.d/bc250-cu-loo.conf"
SERVICE_UNIT="/etc/systemd/system/bc250-cu-loo.service"
SERVICE_NAME="bc250-cu-loo.service"
VERIFY="${BC250_LOO_VERIFY:-/home/kioval/bc250-tools/bc250-compute-verify.sh}"

# Verify load. Bigger numbers = better signal-to-noise on rare defects but slower.
# baseline (40 CU) showed 3 int_errors in ~100M; we need enough work to see
# whether that drops to ~0 with the bad WGP removed.
ELEMENTS="${BC250_LOO_ELEMENTS:-16777216}"
PASSES="${BC250_LOO_PASSES:-3}"
ITERS="${BC250_LOO_ITERS:-64}"
VERIFY_TIMEOUT="${BC250_LOO_TIMEOUT:-120}"

# 20 WGPs: 2 SE × 2 SH × 5 WGPs. CU pair per WGP: (2n, 2n+1).
# Iteration index 1..20 maps to (SE, SH, WGP).
total_iters=20

die() { echo "ERROR: $*" >&2; exit 1; }
log() { printf '\033[0;32m[loo]\033[0m %s\n' "$*"; echo "[$(date '+%F %T')] $*" >>"$LOG" 2>/dev/null || true; }
warn() { printf '\033[0;33m[loo]\033[0m %s\n' "$*" >&2; echo "[$(date '+%F %T')] WARN: $*" >>"$LOG" 2>/dev/null || true; }

require_root() { [ "$(id -u)" = "0" ] || die "must run as root"; }

iter_to_tuple() {
    # in: iter (1..20). out: SE SH WGP CU_A CU_B (printed as 5 fields)
    local i="$1"
    local idx=$((i-1))
    local se=$((idx / 10))
    local rest=$((idx % 10))
    local sh=$((rest / 5))
    local wgp=$((rest % 5))
    echo "$se $sh $wgp $((wgp*2)) $((wgp*2+1))"
}

write_modprobe_conf() {
    # $1 = "SE.SH.CU,SE.SH.CU" (empty string means baseline / full 40 CU)
    local mask="$1"
    if [ -z "$mask" ]; then
        cat >"$MODPROBE_CONF" <<EOF
# bc250-cu-loo: baseline iteration (no WGP disabled, full 40 CU)
# Auto-managed by /home/kioval/bc250-tools/bc250-cu-loo.sh
# To remove manually: rm $MODPROBE_CONF && systemctl disable $SERVICE_NAME
options amdgpu bc250_cc_write_mode=3
EOF
    else
        cat >"$MODPROBE_CONF" <<EOF
# bc250-cu-loo: leave-one-out iteration, mask $mask (38 CU active)
# Auto-managed by /home/kioval/bc250-tools/bc250-cu-loo.sh
# Emergency recovery:
#   rm $MODPROBE_CONF
#   systemctl disable $SERVICE_NAME
#   reboot
options amdgpu bc250_cc_write_mode=3 disable_cu=$mask
EOF
    fi
    log "wrote modprobe.d: ${mask:-baseline}"
}

install_service() {
    cat >"$SERVICE_UNIT" <<EOF
[Unit]
Description=BC-250 CU leave-one-out resume
After=multi-user.target
Wants=multi-user.target

[Service]
Type=oneshot
ExecStartPre=/bin/sleep 15
ExecStart=$(readlink -f "$0") resume
TimeoutStartSec=300
StandardOutput=append:$LOG
StandardError=append:$LOG

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable "$SERVICE_NAME" >/dev/null
    log "installed and enabled $SERVICE_NAME"
}

remove_service() {
    systemctl disable "$SERVICE_NAME" 2>/dev/null || true
    rm -f "$SERVICE_UNIT"
    systemctl daemon-reload
    log "removed $SERVICE_NAME"
}

run_verify() {
    # Runs verify with timeout, returns "errors int_errors fp_errors status time"
    [ -x "$VERIFY" ] || die "verify script not found at $VERIFY"
    local t0 t1 dt out rc status="ok" errs=0 ie=0 fe=0
    t0=$(date +%s.%N)
    if out=$(timeout --kill-after=10 "$VERIFY_TIMEOUT" \
             "$VERIFY" --elements "$ELEMENTS" --passes "$PASSES" --iters "$ITERS" 2>&1); then
        :
    else
        rc=$?
        if [ "$rc" = "124" ] || [ "$rc" = "137" ]; then status="TIMEOUT"
        else status="FAIL($rc)"
        fi
    fi
    t1=$(date +%s.%N)
    dt=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.1f", b-a}')

    if [ "$status" = "ok" ]; then
        local line
        line=$(echo "$out" | grep '^summary ' | tail -1 || true)
        if [ -n "$line" ]; then
            errs=$(echo "$line" | grep -oP 'errors=\K[0-9]+' | head -1)
            ie=$(  echo "$line" | grep -oP 'int_errors=\K[0-9]+')
            fe=$(  echo "$line" | grep -oP 'fp_errors=\K[0-9]+')
        else
            status="NO_SUMMARY"
        fi
    fi

    # Save full verify output too
    echo "===== verify output =====" >>"$LOG"
    echo "$out" >>"$LOG"
    echo "===== end =====" >>"$LOG"

    echo "$errs $ie $fe $status $dt"
}

cmd_start() {
    require_root
    mkdir -p "$STATE_DIR"
    if [ -f "$STATE_FILE" ]; then
        die "test already in progress (state=$(cat "$STATE_FILE")). Run 'cancel' first."
    fi
    [ -x "$VERIFY" ] || die "verify script not found at $VERIFY (BC250_LOO_VERIFY)"
    command -v glslangValidator >/dev/null || die "glslangValidator missing"
    command -v gcc >/dev/null              || die "gcc missing"

    log "=== bc250-cu-loo: START ==="
    log "settings: elements=$ELEMENTS passes=$PASSES iters=$ITERS timeout=${VERIFY_TIMEOUT}s"

    # Init results header
    echo -e "iter\tSE\tSH\tWGP\tCU_a\tCU_b\terrors\tint_errors\tfp_errors\tstatus\ttime_s" >"$RESULTS"
    echo 0 >"$STATE_FILE"   # 0 = baseline iteration on next boot
    write_modprobe_conf ""
    install_service

    cat <<EOF

=================================================================
   bc250-cu-loo armed.

   Test plan:
     iter 0  : baseline (full 40 CU)
     iter 1-20: each disables ONE WGP (always 38 CU active)
     total  : ~10-25 minutes (depending on verify time per iter)

   On the next 21 reboots the system will:
     1. boot to multi-user.target
     2. wait 15s
     3. run compute-verify (timeout ${VERIFY_TIMEOUT}s)
     4. log result to $RESULTS
     5. write the next modprobe.d conf
     6. reboot

   IMPORTANT: Don't do anything important on this PC during the test.
   It will reboot itself ~20 times. Display manager will start each
   time as usual — you can log in if you want, but the next reboot
   may interrupt you.

   To abort: in TTY,  sudo $(readlink -f "$0") cancel
   Recovery: GRUB → Snapshots, or kernel cmdline module_blacklist=amdgpu

   Status anytime:  sudo $(readlink -f "$0") status

   Will reboot in 20 seconds. Ctrl-C to abort.
=================================================================

EOF
    for i in 20 15 10 5 4 3 2 1; do
        printf '\r  rebooting in %2ds...' "$i"
        sleep 1 || { warn "aborted before reboot"; remove_service; rm -f "$MODPROBE_CONF" "$STATE_FILE"; exit 1; }
    done
    echo
    log "rebooting to start test"
    systemctl reboot
}

cmd_resume() {
    require_root
    [ -f "$STATE_FILE" ] || die "no state file ($STATE_FILE) — test not active"
    local state next
    state=$(cat "$STATE_FILE")
    log "=== resume: iter $state of $total_iters ==="

    # Run verify for current state (state 0 = baseline, 1..20 = WGP iterations)
    local mask_label="baseline"
    local se=- sh=- wgp=- cu_a=- cu_b=-
    if [ "$state" -ge 1 ]; then
        read -r se sh wgp cu_a cu_b < <(iter_to_tuple "$state")
        mask_label="${se}.${sh}.${cu_a},${se}.${sh}.${cu_b}"
    fi
    log "current mask: $mask_label"

    local result
    result=$(run_verify)
    local errs ie fe status dt
    read -r errs ie fe status dt <<<"$result"
    log "result: errors=$errs int=$ie fp=$fe status=$status time=${dt}s"

    echo -e "${state}\t${se}\t${sh}\t${wgp}\t${cu_a}\t${cu_b}\t${errs}\t${ie}\t${fe}\t${status}\t${dt}" >>"$RESULTS"

    # Advance state
    next=$((state + 1))
    if [ "$next" -gt "$total_iters" ]; then
        log "=== test complete (all $total_iters iterations done) ==="
        # Cleanup: remove modprobe.d so we boot back to full 40 CU baseline,
        # remove service.
        rm -f "$MODPROBE_CONF"
        rm -f "$STATE_FILE"
        # Restore the original 40 CU config installed by the DKMS package
        cat >"/etc/modprobe.d/bc250-40cu.conf" <<'EOF'
# Enable BC-250 40 CU unlock (set by bc250-amdgpu/install.sh)
options amdgpu bc250_cc_write_mode=3
EOF
        remove_service
        log "rebooting to clean 40 CU state in 15s"
        sleep 15
        systemctl reboot
        return
    fi

    echo "$next" >"$STATE_FILE"
    # Compute next mask
    read -r nse nsh nwgp ncu_a ncu_b < <(iter_to_tuple "$next")
    write_modprobe_conf "${nse}.${nsh}.${ncu_a},${nse}.${nsh}.${ncu_b}"
    log "next iter $next: disable WGP SE${nse}/SH${nsh}/WGP${nwgp} (CUs ${ncu_a},${ncu_b})"
    log "rebooting in 15s"
    sleep 15
    systemctl reboot
}

cmd_status() {
    if [ -f "$STATE_FILE" ]; then
        local state
        state=$(cat "$STATE_FILE")
        echo "Test in progress: iter $state of $total_iters"
    else
        echo "No test in progress."
    fi
    echo
    if [ -f "$RESULTS" ]; then
        echo "Results so far:"
        column -t -s $'\t' "$RESULTS"
    fi
}

cmd_cancel() {
    require_root
    log "=== cancel ==="
    rm -f "$MODPROBE_CONF"
    rm -f "$STATE_FILE"
    cat >"/etc/modprobe.d/bc250-40cu.conf" <<'EOF'
# Enable BC-250 40 CU unlock (set by bc250-amdgpu/install.sh)
options amdgpu bc250_cc_write_mode=3
EOF
    remove_service
    echo "Cancelled. On next reboot system will run full 40 CU."
    echo "Results preserved at $RESULTS (if any)."
}

cmd_show_results() {
    [ -f "$RESULTS" ] || die "no results file"
    echo "Results sorted by int_errors (defect candidates first):"
    {
        head -1 "$RESULTS"
        tail -n +2 "$RESULTS" | sort -t$'\t' -k8,8n
    } | column -t -s $'\t'

    # Simple analysis: which iteration had clearly fewer errors than baseline
    local baseline
    baseline=$(awk -F'\t' '$1=="0" {print $8; exit}' "$RESULTS" 2>/dev/null || echo "?")
    echo
    echo "Baseline int_errors: $baseline"
    echo
    echo "Candidate WGPs (iterations with substantially fewer int_errors than baseline):"
    awk -F'\t' -v b="$baseline" '
        NR==1 {next}
        $1=="0" {next}
        b=="?" {next}
        ($8+0) < (b+0)/2 {
            printf "  iter %s  SE%s SH%s WGP%s  (disable_cu=%s.%s.%s,%s.%s.%s)  int_errors=%s (vs baseline %s)\n",
                   $1, $2, $3, $4, $2, $3, $5, $2, $3, $6, $8, b
        }
    ' "$RESULTS"
}

case "${1:-}" in
    start)        cmd_start "$@";;
    resume)       cmd_resume;;
    step)         cmd_resume;;
    status)       cmd_status;;
    cancel)       cmd_cancel;;
    show-results) cmd_show_results;;
    *)
        cat >&2 <<EOF
Usage: $0 {start|status|cancel|show-results}

  start         arm and begin the test (will reboot)
  status        show progress
  cancel        abort the test, restore baseline 40 CU
  show-results  print results.tsv and candidate analysis

Internal: resume / step  (called by systemd)
EOF
        exit 2
        ;;
esac
